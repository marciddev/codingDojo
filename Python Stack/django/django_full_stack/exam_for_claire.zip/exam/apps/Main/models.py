from django.db import models
from datetime import datetime, timedelta
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
# Create your models here.
class UserManager(models.Manager):
    def validateRegistration(self, postData):
        errors = {}
        if len(postData["register_first_name"])<3 or len(postData["register_last_name"]) < 3:
            errors["name_too_short"] = "Your name must be longer than 2 characters!"
        if not EMAIL_REGEX.match(postData["register_email"]) :
            errors["register_email"] = "Invalid email!"
        if User.objects.filter(email=postData["register_email"]):
            errors["occupied_email"] = "That email is already registered!"
        try:
            if datetime.strptime(postData["register_birthday"], "%Y-%m-%d") >= datetime.now():
                errors["too_young"] = "Birthday must be in the past!"
        except:
            errors["no_birthday"] = "Birthday input was invalid!"
        if len(postData["register_password"]) < 8:
            errors["password_too_short"] = "Password was too short!"
        if postData["register_password"] != postData["register_confirm_password"]:
            errors["matching_passwords"] = "Passwords do not match!"
        return errors
    def validateLogin(self, postData):
        errors = {}
        if len(postData["login_email"]) < 1:
            errors["invalid_email2"] = "Please input an email!"
        if len(postData["login_password"]) < 1:
            errors["invalid_password"] = "Please input a password!"
        return errors
class TravelManager(models.Manager):
    def validateNewTrip(self, postData):
        errors = {}
        if len(postData["trip_new_destination"])< 4 or len(postData["trip_new_plan"]) < 4:
            errors["error1"] = "Your fields must be longer than 3 characters!"
        try:
            if datetime.strptime(postData["trip_new_start_date"], "%Y-%m-%d") <= datetime.now() or datetime.strptime(postData["trip_new_end_date"], "%Y-%m-%d") <= datetime.strptime(postData["trip_new_start_date"], "%Y-%m-%d"):
                errors["trip_to_early"] = "Either your trip start date was too late or your end date was too early!"
        except:
            errors["invalid_format"] = "Invalid trip input!(empty?)"
        return errors
class User(models.Model):
    first_name=models.CharField(max_length=255)
    last_name=models.CharField(max_length=255)
    email=models.CharField(max_length=255)
    birthday=models.DateField()
    password=models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
    def __repr__(self):
        return f"Name: {self.first_name} {self.last_name} EMAIL: {self.email} BIRTHDAY: {self.birthday} ID: {self.id}"
class Travel(models.Model):
    destination = models.CharField(max_length = 255)
    created_by = models.ForeignKey(User, related_name="created_travels")
    start_date = models.DateField()
    end_date = models.DateField()
    joined_by = models.ManyToManyField(User, related_name="joined_travels")
    plan = models.CharField(max_length = 255)
    objects=TravelManager()
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now=True)
