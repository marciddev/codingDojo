from django.shortcuts import render, redirect, HttpResponse
import bcrypt
from .models import *
from django.contrib import messages

# Create your views here.
def home(request):
    return render(request, "Main/register.html")
def register(request):
    if request.method == "POST":
        if request.POST["hide"] == "register":
            errors = User.objects.validateRegistration(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect("/")
            else: 
                first = request.POST["register_first_name"]
                last = request.POST["register_last_name"]
                email = request.POST["register_email"]
                bday = request.POST["register_birthday"]
                unsafePass = request.POST["register_password"]
                hashed_pass = bcrypt.hashpw(unsafePass.encode(), bcrypt.gensalt())
                logged_user = User.objects.create(first_name=first, last_name=last, 
                    email=email,birthday=bday, password=hashed_pass)
                logged_user.save()
                request.session["id"] = logged_user.id
                return redirect("/travels")
def login(request):
    if request.method == "POST":
        if request.POST["hide"] == "login":
            errors = User.objects.validateLogin(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect("/")
            else:
                if User.objects.filter(email=request.POST["login_email"]):
                    logged_user = User.objects.filter(email=request.POST["login_email"])[0]
                    if bcrypt.checkpw(request.POST["login_password"].encode(), logged_user.password.encode()):
                        request.session["id"] = logged_user.id
                        return redirect("/travels")
                    else:
                        messages.error(request, "An email was found, but the password was incorrect!")
                        return redirect("/")
                else:
                    messages.error(request, "No email was found in the database!")
                    return redirect("/")
def welcome(request):
    if 'id' not in request.session:
        return redirect("/")
    else:
        context = {
            "user": User.objects.get(id=request.session["id"]),
            "travels": User.objects.get(id=request.session["id"]).created_travels.all(),
            "two": Travel.objects.exclude(created_by = User.objects.get(id=request.session["id"])),
            "alltravels": Travel.objects.all(),
            "allusertravels": User.objects.get(id=request.session["id"]).joined_travels.all(),
        }
        return render(request, "Main/index.html", context)
def logout(request):
    if 'id' in request.session:
        request.session.clear()
        return redirect("/")
    else:
        messages.error(request, "You arent even logged in!")
        return render(request, "Main/register.html")
def newtrip(request):
    context = {
        "user": User.objects.get(id=request.session["id"]),
    }
    return render(request, "Main/newtrip.html", context)
def addtrip(request):
    if request.method == "POST":
        if request.POST["hide"] == "newtrip":
            errors = Travel.objects.validateNewTrip(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect("/trips/new")
            else:
                if request.POST["submit"] == "Submit":
                    destination = request.POST["trip_new_destination"]
                    created_by = User.objects.get(id=request.session["id"])
                    start_date = request.POST["trip_new_start_date"]
                    end_date = request.POST["trip_new_end_date"]
                    plan = request.POST["trip_new_plan"]
                    Travel.objects.create(destination=destination, created_by = created_by, start_date = start_date, end_date=end_date, plan=plan)
                    return redirect("/travels")
def removetrip(request, id):
    Travel.objects.get(id=id).delete()
    return redirect("/travels")
def jointrip(request, id):
    Travel.objects.get(id=id).joined_by.add(User.objects.get(id=request.session["id"]))
    return redirect("/travels")
def canceltrip(request, id):
    Travel.objects.get(id=id).joined_by.remove(User.objects.get(id=request.session["id"]))
    return redirect("/travels")
def editform(request, id):
    context = {
        "user": User.objects.get(id=request.session["id"]),
        "trip": Travel.objects.get(id=id),
        "start": datetime.strftime(Travel.objects.get(id=id).start_date, "%Y-%m-%d"),
        "end": datetime.strftime(Travel.objects.get(id=id).end_date, "%Y-%m-%d")
    }
    return render(request, "Main/edittrip.html" , context)
def edittrip(request, id):
    if request.method == "POST":
        if request.POST["hide"] == "newtrip":
            errors = Travel.objects.validateNewTrip(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect(f"/trips/edit/{id}")
            else:
                trav =Travel.objects.get(id=id)
                trav.destination = request.POST["trip_new_destination"]
                trav.start_date = request.POST["trip_new_start_date"]
                trav.end_date = request.POST["trip_new_end_date"]
                trav.plan = request.POST["trip_new_plan"]
                trav.save()
                return redirect("/travels")
def tripprofile(request, id):
    context = {
        "user": User.objects.get(id=request.session["id"]),
        "trip": Travel.objects.get(id=id)
    }
    return render(request, "Main/tripprofile.html", context)