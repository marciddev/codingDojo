from django.conf.urls  import url
from  . import views

urlpatterns= [
    url(r'^$', views.home),
    url(r'^register-user$', views.register),
    url(r'^login-user$', views.login),
    url(r'^travels$', views.welcome),
    url(r'^logout$', views.logout),
    url(r'^trips/new$', views.newtrip),
    url(r'^trips/add-trip$', views.addtrip),
    url(r'^travels/remove/(?P<id>\d+)', views.removetrip),
    url(r'^travels/join/(?P<id>\d+)', views.jointrip),
    url(r'^trips/(?P<id>\d+)/cancel', views.canceltrip),
    url(r'^trips/edit-trip/(?P<id>\d+)$', views.editform),
    url(r'^trips/update-trip/(?P<id>\d+)$', views.edittrip),
    url(r'^trips/(?P<id>\d+)$', views.tripprofile)
]