from django.conf.urls  import url
from  . import views

urlpatterns= [
    url(r'^$', views.home),
    url(r'^register-user$', views.register),
    url(r'^login-user$', views.login),
    url(r'^home$', views.welcome),
    url(r'^logout$', views.logout)
]