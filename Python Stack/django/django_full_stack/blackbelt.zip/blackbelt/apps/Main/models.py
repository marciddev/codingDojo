from django.db import models
from apps.registration.models import *
# Create your models here.
class WishManager(models.Manager):
    def validateWish(self, postData):
        errors = {}
        if len(postData["wish_item"]) < 3:
            errors["wish_item"] = "Your item must be at least 3 characters!"
        if len(postData["wish_description"]) < 3:
            errors["wish_desc"] = "Your description must be at least 3 characters!"
        return errors 
class Wish(models.Model):
    item = models.CharField(max_length = 255)
    date_added = models.DateField(null=True)
    wisher = models.ForeignKey(User, related_name="wishes")
    date_granted = models.DateField(null=True)
    liked_by = models.ManyToManyField(User, related_name="likes")
    description = models.CharField(max_length=255)
    objects = WishManager()
    created_at = models.DateTimeField(auto_now_add = True)
    updated_at = models.DateTimeField(auto_now = True)
