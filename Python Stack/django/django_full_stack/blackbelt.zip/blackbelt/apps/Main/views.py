from django.shortcuts import render
from apps.registration.views import *
from apps.registration.models import *
from .models import *
from django.contrib import messages
from datetime import datetime, date
# Create your views here.
def welcome(request):
    if 'id' not in request.session:
        messages.error(request, "YOU MUST BE LOGGED IN")
        return render(request, "registration/index.html")
    nongranted = User.objects.get(id=request.session["id"]).wishes.all().filter(date_granted=None)
    context = {
        "user": User.objects.get(id=request.session["id"]),
        "allusers": User.objects.all(),
        "userwishes": User.objects.get(id=request.session["id"]).wishes.all().filter,
        "pending": nongranted,
        "allwishes": Wish.objects.all(),
    }
    return render(request, "Main/index.html", context)
def make_wish(request):
    context = {
        "user": User.objects.get(id=request.session["id"])
    }
    return render(request, "Main/make_wish.html", context)
def create_wish(request):
    if request.method == "POST":
        if request.POST["hide"] == "add_wish":
            errors = Wish.objects.validateWish(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect("/make-wish")
            else:
                wish = Wish.objects.create(item=request.POST["wish_item"], wisher=User.objects.get(id=request.session["id"]),description=request.POST["wish_description"])
                wish.save()
                wish.date_added=wish.created_at
                wish.save()
                return redirect("/welcome")
def remove_wish(request, id):
    Wish.objects.get(id=id).delete()
    return redirect("/welcome")
def edit_wish(request, id):
    context = {
        "wish": Wish.objects.get(id=id),
        "user": User.objects.get(id=request.session["id"])
    }
    return render(request, "Main/edit_wish.html", context)
def cancel_wish(request):
    return redirect("/welcome")
def update_wish(request, id):
    wish = Wish.objects.get(id=id).id
    if request.method=="POST":
        if request.POST["hide"] == "edit_wish":
            errors= Wish.objects.validateWish(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect(f"/edit-wish/{wish}")
            else:
                wish = Wish.objects.get(id=id)
                wish.item = request.POST["wish_item"]
                wish.description = request.POST["wish_description"]
                wish.save()
                return redirect("/welcome")
def grant_wish(request, id):
    wish = Wish.objects.get(id=id)
    wish.save()
    wish.date_granted = wish.updated_at
    wish.save()
    print(f"{Wish.objects.get(id=id).date_granted}")
    return redirect("/welcome")
def like_wish(request, id):
    wish= Wish.objects.get(id=id)
    wish.liked_by.add(User.objects.get(id=request.session["id"]))
    wish.save()
    return redirect("/welcome")
def user_stats(request):
    count = 0
    nongranted = User.objects.get(id=request.session["id"]).wishes.all().filter(date_granted=None).count
    granted = User.objects.get(id=request.session["id"]).wishes.all().exclude(date_granted=None).count
    context = {
        "allwishes": Wish.objects.exclude(date_granted=None).count,
        "user": User.objects.get(id=request.session["id"]),
        "wishes":Wish.objects.filter(wisher=User.objects.get(id=request.session["id"])),
        "pending": nongranted,
        "granted": granted
    }
    return render(request, "Main/user_stats.html", context)