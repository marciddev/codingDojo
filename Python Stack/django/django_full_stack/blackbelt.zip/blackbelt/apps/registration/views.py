from django.shortcuts import render, redirect
from django.contrib import messages
import bcrypt
from .models import *
from datetime import datetime
# Create your views here.
def index(request):
    return render(request, "registration/index.html")
def register(request):
    if request.method == "POST":
        if request.POST["hide"] == "register":
            errors = User.objects.validateRegistration(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect("/")
            else: 
                first = request.POST["register_first_name"]
                last = request.POST["register_last_name"]
                email = request.POST["register_email"]
                bday = request.POST["register_birthday"]
                unsafePass = request.POST["register_password"]
                hashed_pass = bcrypt.hashpw(unsafePass.encode(), bcrypt.gensalt())
                logged_user = User.objects.create(first_name=first, last_name=last, 
                    email=email,birthday=bday, password=hashed_pass)
                logged_user.save()
                request.session["id"] = logged_user.id
                return redirect("/welcome")
def login(request):
    if request.method == "POST":
        if request.POST["hide"] == "login":
            errors = User.objects.validateLogin(request.POST)
            if len(errors) > 0:
                for k,v in errors.items():
                    messages.error(request, v)
                return redirect("/")
            else:
                if User.objects.filter(email=request.POST["login_email"]):
                    logged_user = User.objects.filter(email=request.POST["login_email"])[0]
                    if bcrypt.checkpw(request.POST["login_password"].encode(), logged_user.password.encode()):
                        request.session["id"] = logged_user.id
                        return redirect("/welcome")
                    else:
                        messages.error(request, "An email was found, but the password was incorrect!")
                        return redirect("/")
                else:
                    messages.error(request, "No email was found in the database!")
                    return redirect("/")
def logout(request):
    if 'id' in request.session:
        request.session.clear()
        return redirect("/")
    else:
        messages.error(request, "You arent even logged in!")
        return render(request, "registration/index.html")