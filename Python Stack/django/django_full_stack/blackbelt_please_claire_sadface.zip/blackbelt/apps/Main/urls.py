from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^welcome$', views.welcome),
    url(r'^make-wish$', views.make_wish),
    url(r'^create-wish$', views.create_wish),
    url(r'^remove-wish/(?P<id>\d+)', views.remove_wish),
    url(r'^edit-wish/(?P<id>\d+)', views.edit_wish),
    url(r'^cancel-wish$', views.cancel_wish),
    url(r'^edit-wish/update-wish/(?P<id>\d+)$', views.update_wish),
    url(r'^grant-wish/(?P<id>\d+)', views.grant_wish),
    url(r'^like-wish/(?P<id>\d+)', views.like_wish),
    url(r'^user-stats$', views.user_stats)
]